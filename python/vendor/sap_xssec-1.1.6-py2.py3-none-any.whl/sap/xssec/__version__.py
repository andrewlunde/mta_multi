""" xssec version """
__version__ = '1.1.6'
